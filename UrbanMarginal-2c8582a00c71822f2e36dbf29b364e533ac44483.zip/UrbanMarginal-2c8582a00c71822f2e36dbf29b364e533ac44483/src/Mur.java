/**
 * Gestion des murs
 *
 */
public class Mur extends Objet {

	/**
	 * Constructeur
	 */
	public Mur() {
	}
	
}
