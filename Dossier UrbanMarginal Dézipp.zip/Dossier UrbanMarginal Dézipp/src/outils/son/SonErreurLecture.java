package outils.son;

import java.io.Serializable;

import outils.son.exceptions.SonException;

/**
 * Exception levée pour signaler une erreur de lecture du son <br>
 */

public class SonErreurLecture
    extends SonException implements Serializable
{
  /**
   * Construit l'exception
   */
  public SonErreurLecture()
  {
    super("Erreur lors de la lecture du son");
  }

  //test java 

}

